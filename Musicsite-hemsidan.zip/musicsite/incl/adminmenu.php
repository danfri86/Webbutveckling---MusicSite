<li><a href="adminArtist.php">Admin Artist</a></li>
<li><a href="adminSong.php">Admin Song</a></li>
<li><a href="adminComment.php">Admin Comment</a></li>
<li><a href="logout.php">Logout</a></li>