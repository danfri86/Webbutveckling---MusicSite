<li><a href="search.php">Search</a></li>
<li><a href="login.php">Login</a></li>